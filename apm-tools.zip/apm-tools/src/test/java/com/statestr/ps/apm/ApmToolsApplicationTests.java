package com.statestr.ps.apm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApmToolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
