package com.statestr.ps.apm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApmToolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApmToolsApplication.class, args);
	}

}
