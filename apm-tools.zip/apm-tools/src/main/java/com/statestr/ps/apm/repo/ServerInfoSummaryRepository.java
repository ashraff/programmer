package com.statestr.ps.apm.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.statestr.ps.apm.model.ServerInfoSummary;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface ServerInfoSummaryRepository extends PagingAndSortingRepository<ServerInfoSummary, Integer> {
	
	@Query("select u from ServerInfoSummary u where upper(u.serverName) like upper('%'||?1||'%') or u.appName=?2")
    List<ServerInfoSummary> findServerByServerorAppName(String serverName, String appName);

}
