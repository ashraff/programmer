package com.statestr.ps.apm.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.statestr.ps.apm.model.ServerInfoSummary;
import com.statestr.ps.apm.repo.ServerInfoSummaryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class IndexController {
	Logger logger = LoggerFactory.getLogger(IndexController.class);

	@Autowired
	private ServerInfoSummaryRepository serverInfoSummaryRepository;

	@GetMapping("/")
	public String homePage() {
		return "index";
	}

	@GetMapping("/contact")
	public String contactPage() {
		return "contact";
	}

	@GetMapping("/about")
	public String aboutPage() {
		return "about";
	}

	@GetMapping("/searchserver")
	public String searchServerPage(@RequestParam(value = "search", required = false) String q, Model model) {
		logger.trace("Request parameter [search] is " + q);
		if (q != null && !StringUtils.isEmpty(q)) {
			List<ServerInfoSummary> serverInfoSummaryList = serverInfoSummaryRepository.findServerByServerorAppName(q,
					q);
			logger.trace("Server Information received is " + serverInfoSummaryList);
			model.addAttribute("servers", serverInfoSummaryList);
		}
		return "searchserver";
	}
}