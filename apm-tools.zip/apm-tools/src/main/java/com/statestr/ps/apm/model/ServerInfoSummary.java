package com.statestr.ps.apm.model;

import java.sql.Timestamp;
import org.hibernate.annotations.Immutable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Immutable
@Table(name = "vw_server_info")
public class ServerInfoSummary {
	
	@Id
	@Column(name = "server_id")
	private int id;
	private String serverName;
	private int appId;
	private String tier;
	private String dataCenter;
	private String purpose;
	private String os;
	private String osVersion;
	private String oneagentVersion;
	private Timestamp lastUpdatedDate;
	private String serverType;
	private String serverSubtype;
	private int envId;
	private String entityId;
	private String serverStatus;
	private String appCode;
	private String appName;
	private String appOrg;
	private String appMailDl;
	private String envName;
	private String clusterName;
	private String environmentGuid;
	private String environmentToken;
	private String status;
	private String envUrl;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	public String getDataCenter() {
		return dataCenter;
	}
	public void setDataCenter(String dataCenter) {
		this.dataCenter = dataCenter;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getOsVersion() {
		return osVersion;
	}
	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}
	public String getOneagentVersion() {
		return oneagentVersion;
	}
	public void setOneagentVersion(String oneagentVersion) {
		this.oneagentVersion = oneagentVersion;
	}
	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getServerType() {
		return serverType;
	}
	public void setServerType(String serverType) {
		this.serverType = serverType;
	}
	public String getServerSubtype() {
		return serverSubtype;
	}
	public void setServerSubtype(String serverSubtype) {
		this.serverSubtype = serverSubtype;
	}
	public int getEnvId() {
		return envId;
	}
	public void setEnvId(int envId) {
		this.envId = envId;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getServerStatus() {
		return serverStatus;
	}
	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppOrg() {
		return appOrg;
	}
	public void setAppOrg(String appOrg) {
		this.appOrg = appOrg;
	}
	public String getAppMailDl() {
		return appMailDl;
	}
	public void setAppMailDl(String appMailDl) {
		this.appMailDl = appMailDl;
	}
	public String getEnvName() {
		return envName;
	}
	public void setEnvName(String envName) {
		this.envName = envName;
	}
	public String getClusterName() {
		return clusterName;
	}
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	public String getEnvironmentGuid() {
		return environmentGuid;
	}
	public void setEnvironmentGuid(String environmentGuid) {
		this.environmentGuid = environmentGuid;
	}
	public String getEnvironmentToken() {
		return environmentToken;
	}
	public void setEnvironmentToken(String environmentToken) {
		this.environmentToken = environmentToken;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEnvUrl() {
		return envUrl;
	}
	public void setEnvUrl(String envUrl) {
		this.envUrl = envUrl;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ServerInfoSummary [id=");
		builder.append(id);
		builder.append(", serverName=");
		builder.append(serverName);
		builder.append(", appId=");
		builder.append(appId);
		builder.append(", tier=");
		builder.append(tier);
		builder.append(", dataCenter=");
		builder.append(dataCenter);
		builder.append(", purpose=");
		builder.append(purpose);
		builder.append(", os=");
		builder.append(os);
		builder.append(", osVersion=");
		builder.append(osVersion);
		builder.append(", oneagentVersion=");
		builder.append(oneagentVersion);
		builder.append(", lastUpdatedDate=");
		builder.append(lastUpdatedDate);
		builder.append(", serverType=");
		builder.append(serverType);
		builder.append(", serverSubtype=");
		builder.append(serverSubtype);
		builder.append(", envId=");
		builder.append(envId);
		builder.append(", entityId=");
		builder.append(entityId);
		builder.append(", serverStatus=");
		builder.append(serverStatus);
		builder.append(", appCode=");
		builder.append(appCode);
		builder.append(", appName=");
		builder.append(appName);
		builder.append(", appOrg=");
		builder.append(appOrg);
		builder.append(", appMailDl=");
		builder.append(appMailDl);
		builder.append(", envName=");
		builder.append(envName);
		builder.append(", clusterName=");
		builder.append(clusterName);
		builder.append(", environmentGuid=");
		builder.append(environmentGuid);
		builder.append(", environmentToken=");
		builder.append(environmentToken);
		builder.append(", status=");
		builder.append(status);
		builder.append(", envUrl=");
		builder.append(envUrl);
		builder.append("]");
		return builder.toString();
	}
	
	
	

}
